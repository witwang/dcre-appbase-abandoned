
extern zend_class_entry *phalcon_assets_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Assets_Exception);

