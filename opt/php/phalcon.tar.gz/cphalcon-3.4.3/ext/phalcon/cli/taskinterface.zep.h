
extern zend_class_entry *phalcon_cli_taskinterface_ce;

ZEPHIR_INIT_CLASS(Phalcon_Cli_TaskInterface);

